#version 330
out vec4 fragment;
void main()
{
	fragment = vec4( 0.0, 1.0, 0.0, 1.0 );
	return;
}